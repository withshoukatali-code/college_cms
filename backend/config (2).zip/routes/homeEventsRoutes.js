import express from "express";
import pool from "../config/db.js";

const router = express.Router();

/*
|--------------------------------------------------------------------------
| GET ACTIVE HOME EVENTS
|--------------------------------------------------------------------------
| GET /api/home-events
|--------------------------------------------------------------------------
*/

router.get("/", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        title,
        description,
        event_date,
        image_url,
        button_text,
        button_link,
        display_order
      FROM home_events
      WHERE is_active = 1
      ORDER BY display_order ASC, id ASC
    `);

    res.json({
      success: true,
      data: rows,
    });
  } catch (error) {
    console.error("GET home events error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch home events",
      error: error.message,
    });
  }
});

/*
|--------------------------------------------------------------------------
| GET ALL HOME EVENTS
|--------------------------------------------------------------------------
| GET /api/home-events/all
|--------------------------------------------------------------------------
*/

router.get("/all", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        title,
        description,
        event_date,
        image_url,
        button_text,
        button_link,
        display_order,
        is_active,
        created_at,
        updated_at
      FROM home_events
      ORDER BY display_order ASC, id ASC
    `);

    res.json({
      success: true,
      data: rows,
    });
  } catch (error) {
    console.error("GET all home events error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch home events",
      error: error.message,
    });
  }
});

/*
|--------------------------------------------------------------------------
| GET SINGLE EVENT
|--------------------------------------------------------------------------
| GET /api/home-events/:id
|--------------------------------------------------------------------------
*/

router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await pool.query(
      `
      SELECT *
      FROM home_events
      WHERE id = ?
      `,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Home event not found",
      });
    }

    res.json({
      success: true,
      data: rows[0],
    });
  } catch (error) {
    console.error("GET home event error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch home event",
      error: error.message,
    });
  }
});

export default router;