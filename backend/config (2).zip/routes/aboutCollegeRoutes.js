import express from "express";
import pool from "../config/db.js";

const router = express.Router();

/*
=========================================================
ABOUT COLLEGE ROUTES
Table: about_college

Admin:
GET    /api/about-college/admin
GET    /api/about-college/admin/:id
POST   /api/about-college/admin
PUT    /api/about-college/admin/:id
DELETE /api/about-college/admin/:id

Public:
GET    /api/about-college
=========================================================
*/


/*
=========================================================
PUBLIC
GET /api/about-college
=========================================================
*/

router.get("/", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        title,
        description,
        image_url,
        button_text,
        button_link,
        is_active,
        display_order
      FROM about_college
      WHERE is_active = 1
      ORDER BY display_order ASC, id ASC
    `);

    res.json(rows);
  } catch (error) {
    console.error("GET /api/about-college error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch About College data",
    });
  }
});


/*
=========================================================
ADMIN
GET /api/about-college/admin
=========================================================
*/

router.get("/admin", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        title,
        description,
        image_url,
        button_text,
        button_link,
        is_active,
        display_order,
        created_at,
        updated_at
      FROM about_college
      ORDER BY display_order ASC, id ASC
    `);

    res.json({
      success: true,
      data: rows,
    });
  } catch (error) {
    console.error("GET /api/about-college/admin error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch About College records",
    });
  }
});


/*
=========================================================
ADMIN
GET /api/about-college/admin/:id
=========================================================
*/

router.get("/admin/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await pool.query(
      `
      SELECT
        id,
        title,
        description,
        image_url,
        button_text,
        button_link,
        is_active,
        display_order,
        created_at,
        updated_at
      FROM about_college
      WHERE id = ?
      `,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "About College record not found",
      });
    }

    res.json({
      success: true,
      data: rows[0],
    });
  } catch (error) {
    console.error("GET /api/about-college/admin/:id error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch About College record",
    });
  }
});


/*
=========================================================
ADMIN
POST /api/about-college/admin
=========================================================
*/

router.post("/admin", async (req, res) => {
  try {
    const {
      title,
      description,
      image_url,
      button_text,
      button_link,
      is_active = 1,
      display_order = 0,
    } = req.body;

    if (!title || !description) {
      return res.status(400).json({
        success: false,
        message: "Title and description are required",
      });
    }

    const [result] = await pool.query(
      `
      INSERT INTO about_college
      (
        title,
        description,
        image_url,
        button_text,
        button_link,
        is_active,
        display_order
      )
      VALUES (?, ?, ?, ?, ?, ?, ?)
      `,
      [
        title,
        description,
        image_url || null,
        button_text || "Read More",
        button_link || "/about-college",
        is_active,
        display_order,
      ]
    );

    res.status(201).json({
      success: true,
      message: "About College created successfully",
      id: result.insertId,
    });
  } catch (error) {
    console.error("POST /api/about-college/admin error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to create About College",
    });
  }
});


/*
=========================================================
ADMIN
PUT /api/about-college/admin/:id
=========================================================
*/

router.put("/admin/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const {
      title,
      description,
      image_url,
      button_text,
      button_link,
      is_active,
      display_order,
    } = req.body;

    if (!title || !description) {
      return res.status(400).json({
        success: false,
        message: "Title and description are required",
      });
    }

    const [result] = await pool.query(
      `
      UPDATE about_college
      SET
        title = ?,
        description = ?,
        image_url = ?,
        button_text = ?,
        button_link = ?,
        is_active = ?,
        display_order = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
      `,
      [
        title,
        description,
        image_url || null,
        button_text || "Read More",
        button_link || "/about-college",
        is_active ?? 1,
        display_order ?? 0,
        id,
      ]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: "About College record not found",
      });
    }

    res.json({
      success: true,
      message: "About College updated successfully",
    });
  } catch (error) {
    console.error("PUT /api/about-college/admin/:id error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to update About College",
    });
  }
});


/*
=========================================================
ADMIN
DELETE /api/about-college/admin/:id
=========================================================
*/

router.delete("/admin/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await pool.query(
      `
      DELETE FROM about_college
      WHERE id = ?
      `,
      [id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        success: false,
        message: "About College record not found",
      });
    }

    res.json({
      success: true,
      message: "About College deleted successfully",
    });
  } catch (error) {
    console.error("DELETE /api/about-college/admin/:id error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to delete About College",
    });
  }
});


export default router;