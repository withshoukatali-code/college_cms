import express from "express";
import pool from "../config/db.js";

const router = express.Router();

/*
|--------------------------------------------------------------------------
| GET ACTIVE YOUTUBE VIDEOS
|--------------------------------------------------------------------------
| GET /api/youtube
|--------------------------------------------------------------------------
*/

router.get("/", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        title,
        description,
        video_url,
        thumbnail_url,
        display_order
      FROM home_youtube
      WHERE is_active = 1
      ORDER BY display_order ASC, id ASC
    `);

    res.json({
      success: true,
      data: rows,
    });
  } catch (error) {
    console.error("GET youtube error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch youtube videos",
      error: error.message,
    });
  }
});

/*
|--------------------------------------------------------------------------
| GET ALL YOUTUBE VIDEOS
|--------------------------------------------------------------------------
| GET /api/youtube/all
|--------------------------------------------------------------------------
*/

router.get("/all", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        title,
        description,
        video_url,
        thumbnail_url,
        display_order,
        is_active,
        created_at,
        updated_at
      FROM home_youtube
      ORDER BY display_order ASC, id ASC
    `);

    res.json({
      success: true,
      data: rows,
    });
  } catch (error) {
    console.error("GET all youtube error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch youtube videos",
      error: error.message,
    });
  }
});

/*
|--------------------------------------------------------------------------
| GET SINGLE YOUTUBE VIDEO
|--------------------------------------------------------------------------
| GET /api/youtube/:id
|--------------------------------------------------------------------------
*/

router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await pool.query(
      `
      SELECT *
      FROM home_youtube
      WHERE id = ?
      `,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Youtube video not found",
      });
    }

    res.json({
      success: true,
      data: rows[0],
    });
  } catch (error) {
    console.error("GET youtube video error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch youtube video",
      error: error.message,
    });
  }
});

export default router;