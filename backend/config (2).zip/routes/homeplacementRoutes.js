import express from "express";
import pool from "../config/db.js";

const router = express.Router();

/*
=========================================================
PUBLIC API
GET /api/home-placements
=========================================================
*/

router.get("/", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        company_name,
        company_logo,
        highest_package,
        average_package,
        students_placed,
        company_website,
        display_order
      FROM home_placements
      WHERE is_active = 1
      ORDER BY display_order ASC, id ASC
    `);

    res.json(rows);
  } catch (error) {
    console.error("GET /api/home-placements error:", error);

    res.status(500).json({
      message: "Failed to fetch placement partners",
      error: error.message,
    });
  }
});


/*
=========================================================
ADMIN API
GET /api/home-placements/admin
=========================================================
*/

router.get("/admin", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        company_name,
        company_logo,
        highest_package,
        average_package,
        students_placed,
        company_website,
        display_order,
        is_active,
        created_at,
        updated_at
      FROM home_placements
      ORDER BY display_order ASC, id ASC
    `);

    res.json(rows);
  } catch (error) {
    console.error("GET /api/home-placements/admin error:", error);

    res.status(500).json({
      message: "Failed to fetch admin placement partners",
      error: error.message,
    });
  }
});


/*
=========================================================
ADMIN API
POST /api/home-placements/admin
=========================================================
*/

router.post("/admin", async (req, res) => {
  try {
    const {
      company_name,
      company_logo = null,
      highest_package = null,
      average_package = null,
      students_placed = null,
      company_website = null,
      display_order = 0,
      is_active = 1,
    } = req.body;

    /*
    -----------------------------------------------------
    VALIDATION
    -----------------------------------------------------
    */

    if (!company_name || !company_name.trim()) {
      return res.status(400).json({
        message: "Company name is required",
      });
    }

    /*
    -----------------------------------------------------
    INSERT
    -----------------------------------------------------
    */

    const [result] = await pool.query(
      `
      INSERT INTO home_placements
      (
        company_name,
        company_logo,
        highest_package,
        average_package,
        students_placed,
        company_website,
        display_order,
        is_active
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        company_name.trim(),
        company_logo || null,
        highest_package !== "" ? highest_package : null,
        average_package !== "" ? average_package : null,
        students_placed !== "" ? students_placed : null,
        company_website || null,
        Number(display_order) || 0,
        is_active ? 1 : 0,
      ]
    );

    /*
    -----------------------------------------------------
    GET CREATED RECORD
    -----------------------------------------------------
    */

    const [rows] = await pool.query(
      `
      SELECT
        id,
        company_name,
        company_logo,
        highest_package,
        average_package,
        students_placed,
        company_website,
        display_order,
        is_active,
        created_at,
        updated_at
      FROM home_placements
      WHERE id = ?
      `,
      [result.insertId]
    );

    res.status(201).json(rows[0]);
  } catch (error) {
    console.error("POST /api/home-placements/admin error:", error);

    res.status(500).json({
      message: "Failed to create placement partner",
      error: error.message,
    });
  }
});


/*
=========================================================
ADMIN API
PUT /api/home-placements/admin/:id
=========================================================
*/

router.put("/admin/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const {
      company_name,
      company_logo = null,
      highest_package = null,
      average_package = null,
      students_placed = null,
      company_website = null,
      display_order = 0,
      is_active = 1,
    } = req.body;

    /*
    -----------------------------------------------------
    VALIDATION
    -----------------------------------------------------
    */

    if (!company_name || !company_name.trim()) {
      return res.status(400).json({
        message: "Company name is required",
      });
    }

    /*
    -----------------------------------------------------
    UPDATE
    -----------------------------------------------------
    */

    const [result] = await pool.query(
      `
      UPDATE home_placements
      SET
        company_name = ?,
        company_logo = ?,
        highest_package = ?,
        average_package = ?,
        students_placed = ?,
        company_website = ?,
        display_order = ?,
        is_active = ?
      WHERE id = ?
      `,
      [
        company_name.trim(),
        company_logo || null,
        highest_package !== "" ? highest_package : null,
        average_package !== "" ? average_package : null,
        students_placed !== "" ? students_placed : null,
        company_website || null,
        Number(display_order) || 0,
        is_active ? 1 : 0,
        id,
      ]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Placement partner not found",
      });
    }

    /*
    -----------------------------------------------------
    GET UPDATED RECORD
    -----------------------------------------------------
    */

    const [rows] = await pool.query(
      `
      SELECT
        id,
        company_name,
        company_logo,
        highest_package,
        average_package,
        students_placed,
        company_website,
        display_order,
        is_active,
        created_at,
        updated_at
      FROM home_placements
      WHERE id = ?
      `,
      [id]
    );

    res.json(rows[0]);
  } catch (error) {
    console.error("PUT /api/home-placements/admin/:id error:", error);

    res.status(500).json({
      message: "Failed to update placement partner",
      error: error.message,
    });
  }
});


/*
=========================================================
ADMIN API
DELETE /api/home-placements/admin/:id
=========================================================
*/

router.delete("/admin/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await pool.query(
      `
      DELETE FROM home_placements
      WHERE id = ?
      `,
      [id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({
        message: "Placement partner not found",
      });
    }

    res.json({
      message: "Placement partner deleted successfully",
    });
  } catch (error) {
    console.error("DELETE /api/home-placements/admin/:id error:", error);

    res.status(500).json({
      message: "Failed to delete placement partner",
      error: error.message,
    });
  }
});


/*
=========================================================
EXPORT ROUTER
=========================================================
*/

export default router;