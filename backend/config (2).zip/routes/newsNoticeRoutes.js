import express from "express";
import pool from "../config/db.js";

const router = express.Router();

// =========================================================
// GET ACTIVE NEWS & NOTICES
// GET /api/news-notices
// =========================================================

router.get("/", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        title,
        category,
        description,
        publish_date,
        link,
        display_order,
        is_active,
        created_at,
        updated_at
      FROM news_notices
      WHERE is_active = 1
      ORDER BY
        display_order ASC,
        publish_date DESC,
        id DESC
    `);

    res.json({
      success: true,
      data: rows,
    });
  } catch (error) {
    console.error("GET news-notices error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch news and notices",
      error: error.message,
    });
  }
});

// =========================================================
// GET ALL
// GET /api/news-notices/all
// =========================================================

router.get("/all", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        title,
        category,
        description,
        publish_date,
        link,
        display_order,
        is_active,
        created_at,
        updated_at
      FROM news_notices
      ORDER BY
        display_order ASC,
        publish_date DESC,
        id DESC
    `);

    res.json({
      success: true,
      data: rows,
    });
  } catch (error) {
    console.error("GET all news-notices error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch all news and notices",
      error: error.message,
    });
  }
});

// =========================================================
// GET SINGLE
// GET /api/news-notices/:id
// =========================================================

router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await pool.query(
      `
      SELECT
        id,
        title,
        category,
        description,
        publish_date,
        link,
        display_order,
        is_active,
        created_at,
        updated_at
      FROM news_notices
      WHERE id = ?
      `,
      [id]
    );

    if (!rows.length) {
      return res.status(404).json({
        success: false,
        message: "News or notice not found",
      });
    }

    res.json({
      success: true,
      data: rows[0],
    });
  } catch (error) {
    console.error("GET single news-notice error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch news or notice",
      error: error.message,
    });
  }
});

// =========================================================
// CREATE
// POST /api/news-notices
// =========================================================

router.post("/", async (req, res) => {
  try {
    const {
      title,
      category,
      description,
      publish_date,
      link,
      display_order,
      is_active,
    } = req.body;

    if (!title?.trim()) {
      return res.status(400).json({
        success: false,
        message: "Title is required",
      });
    }

    const active =
      Number(is_active ?? 1) === 1 ? 1 : 0;

    const order = Number(display_order ?? 0);

    const [result] = await pool.query(
      `
      INSERT INTO news_notices
      (
        title,
        category,
        description,
        publish_date,
        link,
        display_order,
        is_active
      )
      VALUES (?, ?, ?, ?, ?, ?, ?)
      `,
      [
        title.trim(),
        category?.trim() || "News",
        description?.trim() || null,
        publish_date || null,
        link?.trim() || null,
        order,
        active,
      ]
    );

    const [rows] = await pool.query(
      `
      SELECT *
      FROM news_notices
      WHERE id = ?
      `,
      [result.insertId]
    );

    res.status(201).json({
      success: true,
      message: "News/Notice created successfully",
      data: rows[0],
    });
  } catch (error) {
    console.error("CREATE news-notice error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to create news or notice",
      error: error.message,
    });
  }
});

// =========================================================
// UPDATE
// PUT /api/news-notices/:id
// =========================================================

router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const {
      title,
      category,
      description,
      publish_date,
      link,
      display_order,
      is_active,
    } = req.body;

    if (!title?.trim()) {
      return res.status(400).json({
        success: false,
        message: "Title is required",
      });
    }

    const active =
      Number(is_active ?? 1) === 1 ? 1 : 0;

    const order = Number(display_order ?? 0);

    const [result] = await pool.query(
      `
      UPDATE news_notices
      SET
        title = ?,
        category = ?,
        description = ?,
        publish_date = ?,
        link = ?,
        display_order = ?,
        is_active = ?
      WHERE id = ?
      `,
      [
        title.trim(),
        category?.trim() || "News",
        description?.trim() || null,
        publish_date || null,
        link?.trim() || null,
        order,
        active,
        id,
      ]
    );

    if (!result.affectedRows) {
      return res.status(404).json({
        success: false,
        message: "News/Notice not found",
      });
    }

    const [rows] = await pool.query(
      `
      SELECT *
      FROM news_notices
      WHERE id = ?
      `,
      [id]
    );

    res.json({
      success: true,
      message: "News/Notice updated successfully",
      data: rows[0],
    });
  } catch (error) {
    console.error("UPDATE news-notice error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to update news or notice",
      error: error.message,
    });
  }
});

// =========================================================
// DELETE
// DELETE /api/news-notices/:id
// =========================================================

router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await pool.query(
      `
      DELETE FROM news_notices
      WHERE id = ?
      `,
      [id]
    );

    if (!result.affectedRows) {
      return res.status(404).json({
        success: false,
        message: "News/Notice not found",
      });
    }

    res.json({
      success: true,
      message: "News/Notice deleted successfully",
    });
  } catch (error) {
    console.error("DELETE news-notice error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to delete news or notice",
      error: error.message,
    });
  }
});

export default router;