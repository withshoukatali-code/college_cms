import express from "express";
import pool from "../config/db.js";

const router = express.Router();

// GET /api/footer
router.get("/", async (req, res) => {
  try {
    const [rows] = await pool.query(`
      SELECT
        id,
        college_name,
        tagline,
        description,
        affiliation,
        established_year,
        naac_grade,
        address,
        phone,
        email,
        logo,
        copyright_text,
        developer_name
      FROM footer
      WHERE is_active = 1
      ORDER BY id ASC
      LIMIT 1
    `);

    if (rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Footer data not found",
      });
    }

    res.status(200).json({
      success: true,
      data: rows[0],
    });
  } catch (error) {
    console.error("Footer API Error:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch footer data",
    });
  }
});

export default router;