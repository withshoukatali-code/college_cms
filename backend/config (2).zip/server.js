import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { fileURLToPath } from "url";
import path from "path";

import pool from "./config/db.js";

import heroSliderRoutes from "./routes/heroSliderRoutes.js";
import statisticsRoutes from "./routes/statisticsRoutes.js";
import homeEventsRoutes from "./routes/homeEventsRoutes.js";
import youtubeRoutes from "./routes/youtubeRoutes.js";
import homePlacementsRoutes from "./routes/homeplacementRoutes.js";
import homeGalleryRoutes from "./routes/homeGalleryRoutes.js";
import settingsRoutes from "./routes/settingsRoutes.js";
import newsNoticeRoutes from "./routes/newsNoticeRoutes.js";
import breakingNewsRoutes from "./routes/breakingNewsRoutes.js";
import quickLinksRoutes from "./routes/quickLinksRoutes.js";
import footerRoutes from "./routes/footerRoutes.js";
import homeHeroRoutes from "./routes/homeHeroRoutes.js";
import homeStatisticsRoutes from "./routes/homeStatisticsRoutes.js";
import homeWelcomeRoutes from "./routes/homeWelcomeRoutes.js";
import achievementsRoutes from "./routes/achievementsRoutes.js";
import aboutCollegeRoutes from "./routes/aboutCollegeRoutes.js";

dotenv.config();

const app = express();

const PORT = process.env.PORT || 5000;

/*
|--------------------------------------------------------------------------
| PATHS
|--------------------------------------------------------------------------
*/

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const uploadsPath = path.join(
  __dirname,
  "uploads"
);

console.log(
  "Uploads directory:",
  uploadsPath
);

/*
|--------------------------------------------------------------------------
| MIDDLEWARE
|--------------------------------------------------------------------------
*/

app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true,
  })
);

app.use(express.json());

app.use(
  express.urlencoded({
    extended: true,
  })
);

/*
|--------------------------------------------------------------------------
| STATIC UPLOADS
|--------------------------------------------------------------------------
|
| Example:
|
| http://localhost:5000/uploads/gallery/image.webp
|
*/

app.use(
  "/uploads",
  express.static(uploadsPath)
);

/*
|--------------------------------------------------------------------------
| BASIC TEST
|--------------------------------------------------------------------------
*/

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "College CMS Backend Running 🚀",
  });
});

/*
|--------------------------------------------------------------------------
| DATABASE TEST
|--------------------------------------------------------------------------
*/

app.get("/api/test-db", async (req, res) => {
  try {
    const [rows] = await pool.query(
      "SELECT 1 AS connected"
    );

    res.json({
      success: true,
      message:
        "MySQL connected successfully",
      database: process.env.DB_NAME,
      result: rows,
    });
  } catch (error) {
    console.error(
      "Database connection error:",
      error
    );

    res.status(500).json({
      success: false,
      message:
        "MySQL connection failed",
      code: error.code || "",
      error: error.message || "",
    });
  }
});

/*
|--------------------------------------------------------------------------
| API ROUTES
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| HERO SLIDER
|--------------------------------------------------------------------------
*/

app.use(
  "/api/hero-slides",
  heroSliderRoutes
);

app.use(
  "/api/hero-slider",
  heroSliderRoutes
);

/*
|--------------------------------------------------------------------------
| COLLEGE STATISTICS
|--------------------------------------------------------------------------
*/

app.use(
  "/api/college-statistics",
  statisticsRoutes
);

app.use(
  "/api/home-statistics",
  homeStatisticsRoutes
);
/*
|--------------------------------------------------------------------------
| HOMEPAGE
|--------------------------------------------------------------------------
*/

app.use(
  "/api/home-events",
  homeEventsRoutes
);

app.use(
  "/api/home-welcome",
  homeWelcomeRoutes
);

app.use(
  "/api/achievements",
  achievementsRoutes
);

/*
|--------------------------------------------------------------------------
| HOMEPAGE MEDIA / CONTENT
|--------------------------------------------------------------------------
*/

app.use(
  "/api/youtube",
  youtubeRoutes
);

app.use(
  "/api/home-placements",
  homePlacementsRoutes
);

app.use(
  "/api/home-gallery",
  homeGalleryRoutes
);

app.use(
  "/api/quick-links",
  quickLinksRoutes
);

/*
|--------------------------------------------------------------------------
| NEWS
|--------------------------------------------------------------------------
*/

app.use(
  "/api/news-notices",
  newsNoticeRoutes
);

app.use(
  "/api/breaking-news",
  breakingNewsRoutes
);

/*
|--------------------------------------------------------------------------
| SETTINGS / FOOTER
|--------------------------------------------------------------------------
*/

app.use(
  "/api/settings",
  settingsRoutes
);

app.use(
  "/api/footer",
  footerRoutes
);

/*
|--------------------------------------------------------------------------
| ABOUT COLLEGE
|--------------------------------------------------------------------------
*/

app.use(
  "/api/about-college",
  aboutCollegeRoutes
);

/*
|--------------------------------------------------------------------------
| 404 HANDLER
|--------------------------------------------------------------------------
*/

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "API endpoint not found",
    path: req.originalUrl,
  });
});

/*
|--------------------------------------------------------------------------
| START SERVER
|--------------------------------------------------------------------------
*/

app.listen(PORT, () => {
  console.log(
    `College CMS Backend running on http://localhost:${PORT}`
  );
});