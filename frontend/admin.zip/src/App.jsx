import { Routes, Route } from "react-router-dom";

import TopBar from "./features/public/header/TopBar";
import SiteHeader from "./features/public/header/SiteHeader";
import Navbar from "./features/public/navbar/Navbar";
import HomePage from "./features/public/home/HomePage";
import PublicFooter from "./features/public/Footer/PublicFooter"
function App() {
  return (
    <>
      <TopBar />

      <SiteHeader />
      <Navbar/>

      <main className="min-h-screen">
        <Routes>
          <Route path="/" element={<HomePage />} />
        </Routes>
      <PublicFooter/>
      </main>
    </>
  );
}

export default App;