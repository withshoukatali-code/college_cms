import TopBarLink from "./TopBarLink";

function TopBar() {
  const college = {
    establishedYear: "1984",
    affiliation: "Affiliated to Shivaji University, Kolhapur",
    naacGrade: "NAAC A++",
  };

  return (
    <section className="border-b border-slate-800 bg-linear-to-r from-slate-900 via-slate-900 to-slate-800">
      <div className="mx-auto flex h-40px max-w-screen-2xl items-center justify-between px-4 lg:px-8">

        {/* LEFT */}

        <div className="flex items-center text-[11px] font-medium text-slate-300 lg:text-[10px]">

          <span className="whitespace-nowrap">
            Est. {college.establishedYear}
          </span>

          <span className="mx-2 hidden h-3 w-px bg-slate-500/60 md:block" />

          <span className="hidden lg:block whitespace-nowrap">
            {college.affiliation}
          </span>

          <span className="mx-2 hidden h-3 w-px bg-slate-500/60 lg:block" />

          <span className="hidden md:block whitespace-nowrap">
            {college.naacGrade}
          </span>

        </div>

        {/* RIGHT */}

        <nav
          aria-label="Top Navigation"
          className="flex items-center"
        >

          {/* Premium CTA */}

          <TopBarLink
            to="/naac"
            primary
          >
            NAAC DOCUMENTS
          </TopBarLink>

          {/* Desktop */}

          <div className="ml-2 hidden items-center gap-0.5 md:flex">

            <TopBarLink to="/iqac">
              IQAC
            </TopBarLink>

            <TopBarLink to="/naac/aqar">
              AQAR
            </TopBarLink>

            <TopBarLink to="/naac/ssr">
              SSR
            </TopBarLink>

            <TopBarLink to="/naac/dvv">
              DVV
            </TopBarLink>

            <TopBarLink to="/downloads">
              Downloads
            </TopBarLink>

          </div>

        </nav>

      </div>
    </section>
  );
}

export default TopBar;