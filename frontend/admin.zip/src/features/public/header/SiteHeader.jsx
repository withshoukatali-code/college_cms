import CollegeLogo from "./CollegeLogo";
import CollegeInfo from "./CollegeInfo";
import CollegeImage from "./CollegeImage";
import NaacCard from "./NaacCard";

function SiteHeader() {
  // Temporary Data
  // Later this will come from API / Database

  const college = {
    logo: "/images/logo.png",

    tagline: "Knowledge • Character • Service",

    collegeName: "ABC Senior College",

    affiliation:
      "Affiliated to Shivaji University, Kolhapur",

    address:
      "Sangli • Maharashtra • India",

    campusImage:
      "/images/campus.jpg",

    naac: "A++",

    cycle: "Cycle IV",

    cgpa: "CGPA : 3.58",
  };

  return (
    <header
      className="
        border-b
        border-slate-200
        bg-gradient-to-b
        from-white
        to-slate-50
      "
    >
      <div
        className="
          mx-auto
          max-w-screen-2xl
          px-6
          lg:px-10
        "
      >
        <div
          className="
            flex
            items-end
            justify-between
            py-3
          "
        >
          {/* Left */}

          <div
            className="
              flex
              items-center
              gap-8
            "
          >
            <CollegeLogo
              logo={college.logo}
              collegeName={college.collegeName}
            />

            <CollegeInfo
              tagline={college.tagline}
              collegeName={college.collegeName}
              affiliation={college.affiliation}
              address={college.address}
            />
          </div>

          {/* Right */}

          <div
            className="
              hidden
              lg:flex
              items-end
              gap-6
            "
          >
            <CollegeImage
              image={college.campusImage}
            />

            <NaacCard
              grade={college.naac}
              cycle={college.cycle}
              cgpa={college.cgpa}
            />
          </div>
        </div>
      </div>
    </header>
  );
}

export default SiteHeader;