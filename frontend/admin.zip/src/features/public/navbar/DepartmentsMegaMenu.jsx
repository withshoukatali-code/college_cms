import DepartmentColumn from "./DepartmentColumn";


function DepartmentsMegaMenu({ columns }) {

  return (

    <div
      className="
        w-237.5
        rounded-3xl
        border
        border-white/70
        bg-white/95
        backdrop-blur-xl
        p-6
        shadow-[0_20px_60px_rgba(15,23,42,0.18)]
      "
    >


      <div
        className="
          grid
          grid-cols-4
          gap-6
        "
      >

        {
          columns.map((column)=>(
            <DepartmentColumn
              key={column.title}
              column={column}
            />
          ))
        }


      </div>


    </div>

  );

}


export default DepartmentsMegaMenu;