import {
  ShieldCheck,
  Award,
  BadgeCheck,
  FileText,
} from "lucide-react";


export const iqacMenuData = [

  {
    title: "IQAC",
    icon: ShieldCheck,

    items: [
      {
        title: "About IQAC",
        path: "/iqac/about",
      },
      {
        title: "Vision & Mission",
        path: "/iqac/vision-mission",
      },
      {
        title: "IQAC Committee",
        path: "/iqac/committee",
      },
      {
        title: "IQAC Coordinator",
        path: "/iqac/coordinator",
      },
      {
        title: "Minutes of Meetings",
        path: "/iqac/minutes",
      },
      {
        title: "Action Taken Reports",
        path: "/iqac/action-taken",
      },
      {
        title: "Contact IQAC",
        path: "/iqac/contact",
      },
    ],
  },


  {
    title: "NAAC",
    icon: Award,

    items: [
      {
        title: "IIQA",
        path: "/iqac/iiqa",
      },
      {
        title: "SSR",
        path: "/iqac/ssr",
      },
      {
        title: "DVV Clarifications",
        path: "/iqac/dvv",
      },
      {
        title: "Peer Team Visit",
        path: "/iqac/peer-team",
      },
      {
        title: "AQAR (Year-wise)",
        path: "/iqac/aqar",
      },
      {
        title: "NAAC Certificates",
        path: "/iqac/certificates",
      },
      {
        title: "NAAC Documents",
        path: "/iqac/naac-documents",
      },
    ],
  },


  {
    title: "Quality Assurance",
    icon: BadgeCheck,

    items: [
      {
        title: "Best Practices",
        path: "/iqac/best-practices",
      },
      {
        title: "Institutional Distinctiveness",
        path: "/iqac/distinctiveness",
      },
      {
        title: "Academic & Administrative Audit",
        path: "/iqac/aaa",
      },
      {
        title: "Green Audit",
        path: "/iqac/green-audit",
      },
      {
        title: "Energy Audit",
        path: "/iqac/energy-audit",
      },
      {
        title: "Gender Audit",
        path: "/iqac/gender-audit",
      },
      {
        title: "Quality Initiatives",
        path: "/iqac/quality-initiatives",
      },
    ],
  },


  {
    title: "Reports & Policies",
    icon: FileText,

    items: [
      {
        title: "Annual Reports",
        path: "/iqac/annual-reports",
      },
      {
        title: "Stakeholder Feedback",
        path: "/iqac/feedback",
      },
      {
        title: "Policies & Manuals",
        path: "/iqac/policies",
      },
      {
        title: "Code of Conduct",
        path: "/iqac/code-of-conduct",
      },
      {
        title: "Downloads",
        path: "/iqac/downloads",
      },
      {
        title: "Archive",
        path: "/iqac/archive",
      },
    ],
  },

];