import NavItem from "./NavItem";
import { menuData } from "./MenuData";

function DesktopMenu() {
  return (
   <nav className="hidden lg:flex items-center gap-1 relative">
      {menuData.map((item) => (
        <NavItem key={item.title} item={item} />
      ))}
    </nav>
  );
}

export default DesktopMenu;