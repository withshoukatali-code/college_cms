import DesktopMenu from "./DesktopMenu";
import SearchButton from "./SearchButton";

function Navbar() {
  return (
    <header
      className="
        sticky
        top-0
        z-50
        bg-[#0f3262]
        border-b
        border-[#023e92]
        shadow-md
      "
    >
      <div className="mx-auto flex h-12 max-w-screen-2xl items-center px-5 lg:px-8">

        {/* Menu occupies remaining width */}
        <div className="flex-1">
          <DesktopMenu />
        </div>

        <SearchButton />

      </div>
    </header>
  );
}

export default Navbar;