import { Link } from "react-router-dom";
import {
  ChevronRight,
  GraduationCap,
  ShieldCheck,
  Phone,
} from "lucide-react";

function PublicFooter() {
  return (
    <footer className="bg-[#0f3262] text-white">

      {/* Main Footer */}

      <div className="mx-auto max-w-7xl px-6 py-16">

        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">

          {/* About */}

          <div>

            <h3 className="text-xl font-bold">
              Innovative Academy
            </h3>

            <div className="mt-2 h-1 w-16 rounded bg-[#eead09]" />

            <p className="mt-6 text-sm leading-7 text-slate-300">

              Innovative Academy Senior College is committed to
              academic excellence, research, innovation and
              holistic student development through quality
              education.

            </p>

            <div className="mt-8 space-y-2 text-sm text-slate-300">

              <div>NAAC Accredited Institution</div>

              <div>Affiliated to Shivaji University</div>

              <div>Established : 1984</div>

            </div>

          </div>


          {/* Quick Links */}

          <div>

            <h3 className="text-xl font-bold">
              Quick Links
            </h3>

            <div className="mt-2 h-1 w-16 rounded bg-[#eead09]" />

            <div className="mt-6 space-y-3">

              {[
                "About",
                "Admissions",
                "Departments",
                "Library",
                "Research",
                "Gallery",
              ].map((item) => (

                <Link
                  key={item}
                  to="/"
                  className="
                    flex
                    items-center
                    gap-2
                    text-sm
                    text-slate-300
                    transition
                    hover:text-[#eead09]
                  "
                >

                  <ChevronRight size={15} />

                  {item}

                </Link>

              ))}

            </div>

          </div>


          {/* IQAC */}

          <div>

            <h3 className="text-xl font-bold">
              IQAC & Accreditation
            </h3>

            <div className="mt-2 h-1 w-16 rounded bg-[#eead09]" />

            <div className="mt-6 space-y-3">

              {[
                "IQAC",
                "SSR",
                "AQAR",
                "DVV",
                "NAAC",
                "Mandatory Disclosure",
              ].map((item) => (

                <Link
                  key={item}
                  to="/"
                  className="
                    flex
                    items-center
                    gap-2
                    text-sm
                    text-slate-300
                    transition
                    hover:text-[#eead09]
                  "
                >

                  <ShieldCheck size={15} />

                  {item}

                </Link>

              ))}

            </div>

          </div>


          {/* Important Contacts */}

          <div>

            <h3 className="text-xl font-bold">
              Important Contacts
            </h3>

            <div className="mt-2 h-1 w-16 rounded bg-[#eead09]" />

            <div className="mt-6 space-y-3">

              {[
                "Principal Office",
                "IQAC Coordination Office",
                "Placement Office",
                "Women's Grievance Cell",
                "Student Facilitation Centre",
                "Library Help Desk",
              ].map((item) => (

                <Link
                  key={item}
                  to="/"
                  className="
                    flex
                    items-center
                    gap-2
                    text-sm
                    text-slate-300
                    transition
                    hover:text-[#eead09]
                  "
                >

                  <Phone size={15} />

                  {item}

                </Link>

              ))}

            </div>

          </div>

        </div>

      </div>


      {/* Bottom */}

      <div className="border-t border-white/10">

        <div
          className="
            mx-auto
            flex
            max-w-7xl
            flex-col
            items-center
            justify-between
            gap-3
            px-6
            py-6
            text-sm
            text-slate-400
            md:flex-row
          "
        >

          <div>
            © 2026 Innovative Academy Senior College.
            All Rights Reserved.
          </div>

          <div className="flex items-center gap-2">

            <GraduationCap
              size={18}
              className="text-[#eead09]"
            />

            <span>
              Designed & Developed by
            </span>

            <span className="font-semibold text-[#eead09]">
              Innovative Academy
            </span>

          </div>

        </div>

      </div>

    </footer>
  );
}

export default PublicFooter;