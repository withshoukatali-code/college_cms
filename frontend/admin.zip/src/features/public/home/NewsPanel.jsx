import { Link } from "react-router-dom";
import { Newspaper, ChevronRight } from "lucide-react";

const news = [
  {
    id: 1,
    date: "08 Aug",
    title: "Admissions Open for Academic Year 2026–27",
  },
  {
    id: 2,
    date: "06 Aug",
    title: "Scholarship Application Last Date Extended",
  },
  {
    id: 3,
    date: "04 Aug",
    title: "Internal Examination Timetable Published",
  },
  {
    id: 4,
    date: "02 Aug",
    title: "NSS Special Camp Registration Started",
  },
  {
    id: 5,
    date: "30 Jul",
    title: "University Circular for Semester Examination",
  },
  {
    id: 6,
    date: "28 Jul",
    title: "Placement Drive for Final Year Students",
  },
];

function NewsPanel() {
  return (
    <div
      className="
        h-full
        rounded-3xl
        border
        border-slate-200
        bg-white
        p-5
        shadow-sm
      "
    >
      {/* Heading */}

      <div className="mb-4 flex items-center gap-2">

        <Newspaper
          size={20}
          className="text-[#eead09]"
        />

        <h2
          className="
            text-lg
            font-bold
            text-[#0f3262]
          "
        >
          Latest News
        </h2>

      </div>

      {/* Scroll */}

      <div
        className="
          h-77.5
          space-y-3
          overflow-y-auto
          pr-2
        "
      >
        {news.map((item) => (
          <Link
            key={item.id}
            to={`/news/${item.id}`}
            className="
              block
              rounded-xl
              border
              border-slate-100
              p-3
              transition
              hover:border-[#eead09]
              hover:bg-slate-50
            "
          >
            <div
              className="
                text-xs
                font-semibold
                text-[#eead09]
              "
            >
              {item.date}
            </div>

            <div
              className="
                mt-1
                text-sm
                font-medium
                leading-6
                text-slate-700
              "
            >
              {item.title}
            </div>
          </Link>
        ))}
      </div>

      {/* Footer */}

      <div className="mt-4">

        <Link
          to="/news"
          className="
            inline-flex
            items-center
            gap-2
            text-sm
            font-semibold
            text-[#0f3262]
            transition
            hover:text-[#eead09]
          "
        >
          View All

          <ChevronRight size={16} />
        </Link>

      </div>
    </div>
  );
}

export default NewsPanel;