import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

function AboutCollege() {

  const stats = [
    {
      number: "1984",
      label: "Established",
    },
    {
      number: "18+",
      label: "Departments",
    },
    {
      number: "4500+",
      label: "Students",
    },
    {
      number: "120+",
      label: "Faculty",
    },
  ];


  return (

    <section className="bg-slate-50 py-16">

      <div className="mx-auto max-w-7xl px-5 lg:px-8">

        <div className="grid grid-cols-12 gap-10 items-center">

          {/* Left */}

          <div className="col-span-12 lg:col-span-7">

            <span
              className="
                text-xs
                font-semibold
                uppercase
                tracking-[0.2em]
                text-[#eead09]
              "
            >
              About Our Institution
            </span>

            <h2
              className="
                mt-3
                text-4xl
                font-bold
                leading-tight
                text-[#0f3262]
              "
            >
              Excellence in Higher Education
            </h2>

            <p
              className="
                mt-6
                text-[16px]
                leading-8
                text-slate-600
              "
            >
              Our college is committed to academic excellence,
              research, innovation, skill development and value-based
              education. With a learner-centric approach, experienced
              faculty and modern infrastructure, we strive to prepare
              students for global opportunities while nurturing
              responsible citizens.
            </p>

            <Link
              to="/about"
              className="
                mt-8
                inline-flex
                items-center
                gap-2
                rounded-xl
                bg-[#0f3262]
                px-6
                py-3
                text-sm
                font-semibold
                text-white
                transition
                hover:bg-[#163d78]
              "
            >
              Read More

              <ArrowRight size={18}/>
            </Link>

          </div>


          {/* Right */}

          <div className="col-span-12 lg:col-span-5">

            <div className="grid grid-cols-2 gap-5">

              {stats.map((item)=>(

                <div
                  key={item.label}
                  className="
                    rounded-2xl
                    bg-white
                    p-6
                    text-center
                    shadow-sm
                    transition
                    hover:-translate-y-1
                    hover:shadow-xl
                  "
                >

                  <div
                    className="
                      text-4xl
                      font-bold
                      text-[#0f3262]
                    "
                  >
                    {item.number}
                  </div>

                  <div
                    className="
                      mt-3
                      text-sm
                      font-medium
                      text-slate-600
                    "
                  >
                    {item.label}
                  </div>

                </div>

              ))}

            </div>

          </div>

        </div>

      </div>

    </section>

  );

}

export default AboutCollege;