import { Link } from "react-router-dom";

import {
  GraduationCap,
  Building2,
  ShieldCheck,
  Award,
  Library,
  Download,
  BookOpen,
  Users,
} from "lucide-react";


const links = [

  {
    title: "Admissions",
    path: "/admissions",
    icon: GraduationCap,
  },

  {
    title: "Departments",
    path: "/departments",
    icon: Building2,
  },

  {
    title: "IQAC",
    path: "/iqac",
    icon: ShieldCheck,
  },

  {
    title: "Accreditation",
    path: "/accreditation",
    icon: Award,
  },

  {
    title: "Library",
    path: "/library",
    icon: Library,
  },

  {
    title: "Downloads",
    path: "/downloads",
    icon: Download,
  },

  {
    title: "Research",
    path: "/research",
    icon: BookOpen,
  },

  {
    title: "Student Corner",
    path: "/students",
    icon: Users,
  },

];


function QuickLinks() {

  return (

    <section className="bg-white py-16">

      <div className="mx-auto max-w-7xl px-5 lg:px-8">

        <div className="text-center">

          <span
            className="
              text-xs
              font-semibold
              uppercase
              tracking-[0.2em]
              text-[#eead09]
            "
          >
            Quick Access
          </span>

          <h2
            className="
              mt-3
              text-4xl
              font-bold
              text-[#0f3262]
            "
          >
            Explore the College
          </h2>

        </div>


        <div
          className="
            mt-12
            grid
            grid-cols-2
            gap-5
            md:grid-cols-4
            lg:grid-cols-4
          "
        >

          {links.map((item)=>{

            const Icon = item.icon;

            return (

              <Link
                key={item.title}
                to={item.path}
                className="
                  group
                  rounded-2xl
                  border
                  border-slate-200
                  bg-white
                  p-6
                  text-center
                  shadow-sm
                  transition-all
                  duration-300
                  hover:-translate-y-2
                  hover:border-[#eead09]
                  hover:shadow-xl
                "
              >

                <div
                  className="
                    mx-auto
                    flex
                    h-16
                    w-16
                    items-center
                    justify-center
                    rounded-2xl
                    bg-[#0f3262]
                    transition
                    group-hover:bg-[#eead09]
                  "
                >

                  <Icon
                    size={30}
                    className="text-white"
                  />

                </div>


                <h3
                  className="
                    mt-5
                    text-[15px]
                    font-semibold
                    text-[#0f3262]
                  "
                >
                  {item.title}
                </h3>

              </Link>

            );

          })}

        </div>

      </div>

    </section>

  );

}

export default QuickLinks;