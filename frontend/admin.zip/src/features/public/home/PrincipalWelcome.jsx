import {
  CalendarDays,
  Trophy,
  ArrowRight,
  Quote,
  // Sparkles,
} from "lucide-react";

/* =========================================================
   DUMMY EVENTS & ACTIVITIES
========================================================= */

const events = [
  {
    date: "25",
    month: "AUG",
    title: "National Seminar on AI & Data Science",
    category: "Seminar",
  },
  {
    date: "20",
    month: "AUG",
    title: "Independence Day Celebration",
    category: "Campus Activity",
  },
  {
    date: "18",
    month: "AUG",
    title: "Inter-Collegiate Sports Competition",
    category: "Sports",
  },
  {
    date: "12",
    month: "AUG",
    title: "NSS Community Outreach Programme",
    category: "NSS Activity",
  },
  {
    date: "08",
    month: "AUG",
    title: "Student Development Workshop",
    category: "Workshop",
  },
  {
    date: "02",
    month: "AUG",
    title: "Career Guidance & Placement Drive",
    category: "Career",
  },
];

/* =========================================================
   DUMMY ACHIEVEMENTS
========================================================= */

const achievements = [
  {
    title: "NAAC Accredited Institution",
    description:
      "Recognized for academic excellence and quality-driven institutional practices.",
  },
  {
    title: "Outstanding Student Achievements",
    description:
      "Students have represented the institution at university, state and national levels.",
  },
  {
    title: "Excellence in Academic Activities",
    description:
      "Faculty and students actively participate in research, seminars and academic initiatives.",
  },
];

/* =========================================================
   DUMMY PRINCIPAL
========================================================= */

const principal = {
  name: "Dr. A. K. Sharma",
  designation: "Principal",

  // Generic dummy avatar
  image: "https://i.pravatar.cc/300?img=12",

  message:
    "It gives me immense pleasure to welcome you to our institution. Our college is committed to providing quality education and creating an environment where students can develop knowledge, skills, confidence and strong values.",
};

/* =========================================================
   EVENT ITEM
========================================================= */

function EventItem({ event }) {
  return (
    <div className="group flex gap-4 border-b border-slate-100 py-4">
      {/* DATE */}

      <div className="flex h-12 w-14 shrink-0 flex-col items-center justify-center rounded-lg bg-blue-50 text-blue-700">
        <span className="text-base font-bold leading-none">
          {event.date}
        </span>

        <span className="mt-1 text-[9px] font-bold tracking-wider">
          {event.month}
        </span>
      </div>

      {/* DETAILS */}

      <div className="min-w-0 flex-1">
        <p className="mb-1 text-[10px] font-bold uppercase tracking-wider text-blue-600">
          {event.category}
        </p>

        <h4 className="text-sm font-semibold leading-5 text-slate-800 transition group-hover:text-blue-700">
          {event.title}
        </h4>

        <button
          type="button"
          className="mt-2 inline-flex items-center gap-1 text-xs font-semibold text-slate-400 transition hover:text-blue-700"
        >
          View Details
          <ArrowRight size={11} />
        </button>
      </div>
    </div>
  );
}

/* =========================================================
   MAIN COMPONENT
========================================================= */

function HomeWelcome() {
  return (
    <>
      {/* =====================================================
          SCROLLING ANIMATION
      ====================================================== */}

      <style>{`
        .events-scroll-wrapper {
          height: 330px;
          overflow: hidden;
          position: relative;
        }

        .events-scroll-track {
          display: flex;
          flex-direction: column;
          animation: eventsVerticalScroll 24s linear infinite;
          will-change: transform;
        }

        .events-scroll-wrapper:hover .events-scroll-track {
          animation-play-state: paused;
        }

        @keyframes eventsVerticalScroll {
          0% {
            transform: translateY(0);
          }

          100% {
            transform: translateY(-50%);
          }
        }
      `}</style>

      <section className="bg-white py-14 md:py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

          {/* =================================================
              SECTION HEADING
          ================================================== */}

          {/* <div className="mb-10 text-center">

            <div className="inline-flex items-center gap-2 rounded-full bg-blue-50 px-4 py-2 text-sm font-semibold text-blue-700">
              <Sparkles size={15} />

              Our Institution
            </div>

            <h2 className="mt-4 text-3xl font-bold tracking-tight text-[#0f3262] md:text-4xl">
              Welcome to Our College
            </h2>

            <div className="mx-auto mt-4 h-1 w-14 rounded-full bg-blue-600" />

          </div> */}

          {/* =================================================
              MAIN GRID
          ================================================== */}

          <div className="grid gap-8 lg:grid-cols-[1.35fr_0.9fr]">

            {/* =================================================
                LEFT — WELCOME + PRINCIPAL
            ================================================== */}

            <div className="rounded-2xl border border-slate-200 bg-white shadow-sm">

              {/* HEADER */}

              <div className="border-b border-slate-100 px-6 py-6 md:px-8">

                <p className="text-sm font-semibold uppercase tracking-[0.18em] text-blue-600">
                  Welcome Message
                </p>

                <h3 className="mt-2 text-2xl font-bold text-slate-900 md:text-3xl">
                  A Place to Learn, Grow & Excel
                </h3>

              </div>

              {/* CONTENT */}

              <div className="px-6 py-7 md:px-8">

                {/* PRINCIPAL */}

                <div className="flex flex-col gap-6 sm:flex-row">

                  {/* PHOTO */}

                  <div className="shrink-0">
                    <div className="mx-auto h-40 w-32 overflow-hidden rounded-xl bg-slate-100 shadow-sm sm:mx-0">

                      <img
                        src={principal.image}
                        alt="Principal"
                        className="h-full w-full object-cover"
                      />

                    </div>
                  </div>

                  {/* NAME */}

                  <div className="flex-1">

                    <div className="mb-3 flex items-center gap-2 text-blue-600">

                      <Quote size={18} />

                      <span className="text-sm font-semibold uppercase tracking-wider">
                        Principal's Message
                      </span>

                    </div>

                    <h4 className="text-xl font-bold text-slate-900">
                      {principal.name}
                    </h4>

                    <p className="mt-1 text-sm font-medium text-blue-600">
                      {principal.designation}
                    </p>

                    <p className="mt-4 text-[14px] leading-6 text-slate-600">
                      {principal.message}
                    </p>

                  </div>

                </div>

                {/* ADDITIONAL MESSAGE */}

                <div className="mt-6">

                  <p className="text-[15px] leading-7 text-slate-600">
                    With the support of our dedicated faculty, staff,
                    students and stakeholders, we continuously strive to
                    create a vibrant academic environment that encourages
                    innovation, research, creativity and holistic
                    development.
                  </p>

                  <p className="mt-4 text-[15px] leading-7 text-slate-600">
                    We believe that education is not merely about academic
                    achievement. It is about developing responsible,
                    confident and compassionate individuals who are prepared
                    to contribute meaningfully to society.
                  </p>

                </div>

                {/* HIGHLIGHTS */}

                <div className="mt-7 grid gap-3 sm:grid-cols-3">

                  <div className="rounded-xl bg-slate-50 p-4">
                    <h5 className="font-bold text-[#0f3262]">
                      Excellence
                    </h5>

                    <p className="mt-1 text-xs leading-5 text-slate-500">
                      Academic excellence and quality education
                    </p>
                  </div>

                  <div className="rounded-xl bg-slate-50 p-4">
                    <h5 className="font-bold text-[#0f3262]">
                      Innovation
                    </h5>

                    <p className="mt-1 text-xs leading-5 text-slate-500">
                      Research, creativity and innovation
                    </p>
                  </div>

                  <div className="rounded-xl bg-slate-50 p-4">
                    <h5 className="font-bold text-[#0f3262]">
                      Development
                    </h5>

                    <p className="mt-1 text-xs leading-5 text-slate-500">
                      Holistic student development
                    </p>
                  </div>

                </div>

                {/* READ MORE */}

                <button
                  type="button"
                  className="mt-7 inline-flex items-center gap-2 rounded-lg bg-[#0f3262] px-5 py-3 text-sm font-semibold text-white transition hover:bg-blue-800"
                >
                  Read More

                  <ArrowRight size={16} />
                </button>

              </div>
            </div>

            {/* =================================================
                RIGHT COLUMN
            ================================================== */}

            <div className="space-y-7">

              {/* =================================================
                  EVENTS & ACTIVITIES
              ================================================== */}

              <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

                {/* HEADER */}

                <div className="flex items-center justify-between bg-[#0f3262] px-5 py-4">

                  <div className="flex items-center gap-3">

                    <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/10">

                      <CalendarDays
                        size={19}
                        className="text-white"
                      />

                    </div>

                    <div>

                      <h3 className="font-bold text-white">
                        Events & Activities
                      </h3>

                      <p className="text-xs text-blue-100">
                        Latest college activities
                      </p>

                    </div>

                  </div>

                  <button
                    type="button"
                    className="text-xs font-semibold text-blue-100 transition hover:text-white"
                  >
                    View All
                  </button>

                </div>

                {/* =============================================
                    VERTICAL SCROLLING
                ============================================== */}

                <div className="events-scroll-wrapper">

                  <div className="events-scroll-track px-5">

                    {/* FIRST SET */}

                    {events.map((event, index) => (
                      <EventItem
                        key={`first-${index}`}
                        event={event}
                      />
                    ))}

                    {/* DUPLICATE SET
                        Required for seamless infinite scrolling */}

                    {events.map((event, index) => (
                      <EventItem
                        key={`second-${index}`}
                        event={event}
                      />
                    ))}

                  </div>

                </div>

              </div>

              {/* =================================================
                  ACHIEVEMENTS
              ================================================== */}

              <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">

                {/* HEADER */}

                <div className="flex items-center gap-3 border-b border-slate-100 px-5 py-4">

                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-50">

                    <Trophy
                      size={19}
                      className="text-amber-600"
                    />

                  </div>

                  <div>

                    <h3 className="font-bold text-slate-900">
                      Achievements
                    </h3>

                    <p className="text-xs text-slate-500">
                      Celebrating excellence
                    </p>

                  </div>

                </div>

                {/* LIST */}

                <div className="divide-y divide-slate-100">

                  {achievements.map((achievement, index) => (

                    <div
                      key={index}
                      className="flex gap-3 px-5 py-4"
                    >

                      <div className="mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-50">

                        <Trophy
                          size={13}
                          className="text-amber-600"
                        />

                      </div>

                      <div>

                        <h4 className="text-sm font-semibold text-slate-800">
                          {achievement.title}
                        </h4>

                        <p className="mt-1 text-xs leading-5 text-slate-500">
                          {achievement.description}
                        </p>

                      </div>

                    </div>

                  ))}

                </div>

              </div>

            </div>

          </div>

        </div>
      </section>
    </>
  );
}

export default HomeWelcome;