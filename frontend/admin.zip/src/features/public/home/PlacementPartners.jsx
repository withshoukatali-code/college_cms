const partners = [
  {
    id: 1,
    name: "TCS",
    logo: "https://dummyimage.com/180x90/f8fafc/334155&text=TCS",
  },
  {
    id: 2,
    name: "Infosys",
    logo: "https://dummyimage.com/180x90/f8fafc/334155&text=Infosys",
  },
  {
    id: 3,
    name: "Wipro",
    logo: "https://dummyimage.com/180x90/f8fafc/334155&text=Wipro",
  },
  {
    id: 4,
    name: "Capgemini",
    logo: "https://dummyimage.com/180x90/f8fafc/334155&text=Capgemini",
  },
  {
    id: 5,
    name: "HCL",
    logo: "https://dummyimage.com/180x90/f8fafc/334155&text=HCL",
  },
  {
    id: 6,
    name: "Tech Mahindra",
    logo: "https://dummyimage.com/180x90/f8fafc/334155&text=Tech+Mahindra",
  },
];

function PlacementPartners() {
  return (
    <section className="bg-slate-50 py-16">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">

        <div className="text-center">

          <span
            className="
              text-xs
              font-semibold
              uppercase
              tracking-[0.2em]
              text-[#eead09]
            "
          >
            Industry Connect
          </span>

          <h2
            className="
              mt-3
              text-4xl
              font-bold
              text-[#0f3262]
            "
          >
            Our Recruiters & Placement Partners
          </h2>

          <p className="mx-auto mt-5 max-w-2xl text-slate-600 leading-8">
            Our students receive opportunities through leading companies
            and industry collaborations that support career development
            and professional growth.
          </p>

        </div>

        <div className="mt-12 grid grid-cols-2 gap-6 md:grid-cols-3 lg:grid-cols-6">

          {partners.map((partner) => (

            <div
              key={partner.id}
              className="
                rounded-2xl
                border
                border-slate-200
                bg-white
                p-6
                shadow-sm
                transition
                duration-300
                hover:-translate-y-1
                hover:shadow-lg
              "
            >

              <img
                src={partner.logo}
                alt={partner.name}
                className="
                  h-14
                  w-full
                  object-contain
                  grayscale
                  transition
                  duration-300
                  hover:grayscale-0
                "
              />

            </div>

          ))}

        </div>

      </div>
    </section>
  );
}

export default PlacementPartners;