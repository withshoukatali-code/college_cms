import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const images = [
  "https://images.unsplash.com/photo-1562774053-701939374585?w=900",
  "https://images.unsplash.com/photo-1523050854058-8df90110c9f?w=900",
  "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=900",
  "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=900",
  "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=900",
  "https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?w=900",
  "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=900",
  "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=900",
];

function GalleryPreview() {
  return (
    <section className="bg-slate-50 py-16">

      <div className="mx-auto max-w-7xl px-5 lg:px-8">

        {/* Heading */}

        <div className="mb-10 flex items-end justify-between">

          <div>

            <span
              className="
                text-xs
                font-semibold
                uppercase
                tracking-[0.2em]
                text-[#eead09]
              "
            >
              Campus Gallery
            </span>

            <h2
              className="
                mt-3
                text-4xl
                font-bold
                text-[#0f3262]
              "
            >
              Life at Our Campus
            </h2>

          </div>

          <Link
            to="/gallery"
            className="
              hidden
              items-center
              gap-2
              text-sm
              font-semibold
              text-[#0f3262]
              transition
              hover:text-[#eead09]
              md:flex
            "
          >
            View Gallery

            <ArrowRight size={18} />

          </Link>

        </div>

        {/* Gallery Grid */}

        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">

          {images.map((image, index) => (

            <Link
              key={index}
              to="/gallery"
              className="
                group
                overflow-hidden
                rounded-2xl
              "
            >

              <img
                src={image}
                alt=""
                className="
                  h-52
                  w-full
                  object-cover
                  transition
                  duration-500
                  group-hover:scale-110
                "
              />

            </Link>

          ))}

        </div>

        {/* Mobile Button */}

        <div className="mt-8 text-center md:hidden">

          <Link
            to="/gallery"
            className="
              inline-flex
              items-center
              gap-2
              rounded-xl
              bg-[#0f3262]
              px-6
              py-3
              font-semibold
              text-white
            "
          >
            View Gallery

            <ArrowRight size={18} />

          </Link>

        </div>

      </div>

    </section>
  );
}

export default GalleryPreview;