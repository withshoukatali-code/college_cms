import { Link } from "react-router-dom";
import { PlayCircle, ArrowRight } from "lucide-react";

const videos = [
  {
    id: 1,
    title: "Campus Tour",
    thumbnail: "https://img.youtube.com/vi/ysz5S6PUM-U/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=ysz5S6PUM-U",
  },
  {
    id: 2,
    title: "Admission Process",
    thumbnail: "https://img.youtube.com/vi/jNQXAC9IVRw/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=jNQXAC9IVRw",
  },
  {
    id: 3,
    title: "NAAC Activities",
    thumbnail: "https://img.youtube.com/vi/aqz-KE-bpKQ/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=aqz-KE-bpKQ",
  },
  {
    id: 4,
    title: "Annual Gathering",
    thumbnail: "https://img.youtube.com/vi/M7lc1UVf-VE/maxresdefault.jpg",
    url: "https://www.youtube.com/watch?v=M7lc1UVf-VE",
  },
];

function YoutubeSection() {
  return (
    <section className="bg-white py-16">

      <div className="mx-auto max-w-7xl px-5 lg:px-8">

        {/* Heading */}

        <div className="mb-10 flex items-end justify-between">

          <div>

            <span
              className="
                text-xs
                font-semibold
                uppercase
                tracking-[0.2em]
                text-[#eead09]
              "
            >
              Videos
            </span>

            <h2
              className="
                mt-3
                text-4xl
                font-bold
                text-[#0f3262]
              "
            >
              Explore Our College
            </h2>

          </div>

          <Link
            to="/videos"
            className="
              hidden
              items-center
              gap-2
              text-sm
              font-semibold
              text-[#0f3262]
              transition
              hover:text-[#eead09]
              md:flex
            "
          >
            View All

            <ArrowRight size={18}/>
          </Link>

        </div>

        {/* Videos */}

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">

          {videos.map((video)=>(

            <a
              key={video.id}
              href={video.url}
              target="_blank"
              rel="noopener noreferrer"
              className="
                group
                overflow-hidden
                rounded-2xl
                border
                border-slate-200
                bg-white
                shadow-sm
                transition
                hover:shadow-xl
              "
            >

              <div className="relative">

                <img
                  src={video.thumbnail}
                  alt={video.title}
                  className="
                    h-52
                    w-full
                    object-cover
                  "
                />

                <div
                  className="
                    absolute
                    inset-0
                    flex
                    items-center
                    justify-center
                    bg-black/30
                    transition
                    group-hover:bg-black/40
                  "
                >

                  <PlayCircle
                    size={65}
                    className="
                      text-white
                      transition
                      group-hover:scale-110
                    "
                  />

                </div>

              </div>

              <div className="p-5">

                <h3
                  className="
                    text-base
                    font-semibold
                    text-[#0f3262]
                  "
                >
                  {video.title}
                </h3>

              </div>

            </a>

          ))}

        </div>

      </div>

    </section>
  );
}

export default YoutubeSection;