import HeroSlider from "./HeroSlider";
import BreakingNews from "./BreakingNews";
import PrincipalWelcome from "./PrincipalWelcome";
// import AboutCollege from "./AboutCollege";
import Event from "./Events"
import PlacementPartner from "./PlacementPartners"
import YoutubeSection from "./YoutubeSection"
import AboutPreview from"./AboutPreview"


function HomePage() {
  return (
    <main className="w-full bg-white">
      <HeroSlider />

      <BreakingNews />

      <PrincipalWelcome />
<AboutPreview/>
      {/* <AboutCollege /> */}
     <Event/>
     <PlacementPartner/>
    
    <YoutubeSection/>
    </main>
  );
}

export default HomePage;