import { Link } from "react-router-dom";

function HeroSlide({ slide, active }) {
  return (
    <div
      className={`
        absolute inset-0
        transition-all duration-700
        ${
          active
            ? "opacity-100 scale-100 z-10"
            : "opacity-0 scale-105 z-0"
        }
      `}
    >
      {/* Background */}

      <img
        src={slide.image}
        alt={slide.title}
        className="h-full w-full object-cover"
      />

      {/* Overlay */}

      <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/40 to-black/20" />

      {/* Content */}

      <div className="absolute inset-0 flex items-center">

        <div className="mx-auto max-w-7xl px-6">

          <div className="max-w-2xl">

            <span
              className="
                rounded-full
                bg-[#eead09]
                px-4
                py-2
                text-sm
                font-semibold
                text-white
              "
            >
              Admission 2026/27
            </span>

            <h1
              className="
                mt-6
                text-5xl
                font-bold
                leading-tight
                text-white
                lg:text-6xl
              "
            >
              {slide.title}
            </h1>

            <h2
              className="
                mt-4
                text-2xl
                font-semibold
                text-[#eead09]
              "
            >
              {slide.subtitle}
            </h2>

            <p
              className="
                mt-6
                text-lg
                leading-8
                text-slate-200
              "
            >
              {slide.description}
            </p>

            <div className="mt-10 flex flex-wrap gap-4">

              <Link
                to="/admissions"
                className="
                  rounded-xl
                  bg-[#eead09]
                  px-7
                  py-4
                  font-semibold
                  text-white
                  transition
                  hover:bg-[#d99905]
                "
              >
                Apply Now
              </Link>

              <Link
                to="/departments"
                className="
                  rounded-xl
                  border
                  border-white
                  px-7
                  py-4
                  font-semibold
                  text-white
                  transition
                  hover:bg-white
                  hover:text-[#0f3262]
                "
              >
                Explore Departments
              </Link>

            </div>

          </div>

        </div>

      </div>
    </div>
  );
}

export default HeroSlide;