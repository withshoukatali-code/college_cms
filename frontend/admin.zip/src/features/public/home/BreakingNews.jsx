import { Megaphone } from "lucide-react";

const news = [
  "Admissions Open for Academic Year 2026-27.",
  "NAAC Peer Team Visit Scheduled Next Month.",
  "FYUG Admission Merit List Published.",
  "National Seminar on AI & Data Science on 25th August.",
  "Scholarship Forms Available in Student Section.",
];

function BreakingNews() {
  return (
    <section className="border-y border-slate-200 bg-[#eead09]">

      <div className="mx-auto flex h-12 max-w-7xl items-center overflow-hidden">

        {/* Label */}

        <div
          className="
            flex
            h-full
            shrink-0
            items-center
            gap-2
            bg-[#0f3262]
            px-6
            text-white
            font-semibold
            tracking-wide
          "
        >
          <Megaphone size={18} />

          Breaking News
        </div>

        {/* Marquee */}

        <div className="relative flex-1 overflow-hidden">

          <div className="breaking-marquee whitespace-nowrap">

            {news.concat(news).map((item, index) => (
              <span
                key={index}
                className="mx-10 inline-block text-[15px] font-medium text-slate-900"
              >
                ● {item}
              </span>
            ))}

          </div>

        </div>

      </div>

    </section>
  );
}

export default BreakingNews;