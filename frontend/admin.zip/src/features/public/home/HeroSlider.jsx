import { useEffect, useState } from "react";

const slides = [
  {
    image:
      "https://images.unsplash.com/photo-1564981797816-1043664bf78d?auto=format&fit=crop&w=2200&q=85",
    eyebrow: "WELCOME TO OUR COLLEGE",
    title: "Empowering Knowledge.",
    highlight: "Inspiring Futures.",
    description:
      "A commitment to academic excellence, meaningful research and holistic development.",
  },
  {
    image:
      "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=2200&q=85",
    eyebrow: "ACADEMIC EXCELLENCE",
    title: "Learn. Discover.",
    highlight: "Achieve.",
    description:
      "Creating opportunities for students to learn, innovate and grow in a vibrant academic environment.",
  },
  {
    image:
      "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=2200&q=85",
    eyebrow: "A CULTURE OF EXCELLENCE",
    title: "Education With",
    highlight: "Purpose.",
    description:
      "Building responsible, skilled and confident graduates prepared for tomorrow.",
  },
  {
    image:
      "https://images.unsplash.com/photo-1498243691581-b145c3f54a5a?auto=format&fit=crop&w=2200&q=85",
    eyebrow: "RESEARCH & INNOVATION",
    title: "Discover.",
    highlight: "Innovate. Lead.",
    description:
      "Encouraging curiosity, research and innovation to create meaningful impact in society.",
  },
  {
    image:
      "https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?auto=format&fit=crop&w=2200&q=85",
    eyebrow: "STUDENT LIFE",
    title: "Beyond the",
    highlight: "Classroom.",
    description:
      "A dynamic campus experience that supports academic, cultural, social and personal growth.",
  },
];

const statistics = [
  {
    value: "1984",
    label: "Established",
  },
  {
    value: "18+",
    label: "Departments",
  },
  {
    value: "4500+",
    label: "Students",
  },
  {
    value: "120+",
    label: "Faculty",
  },
];

function HeroSlider() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % slides.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const slide = slides[current];

  return (
    <section className="w-full">
      {/* Hero Slider */}
      <div className="relative h-115 w-full overflow-hidden bg-[#0F3262]">
        {/* Background */}
        <img
          key={slide.image}
          src={slide.image}
          alt=""
          className="absolute inset-0 h-full w-full object-cover"
        />

        {/* Overlay */}
     <div
  className="
    absolute
    inset-0
    bg-linear-to-r
    from-[#061A34]/65
    via-[#0F3262]/35
    to-transparent
  "
/>

        {/* Hero Content */}
        <div className="relative z-10 mx-auto flex h-full max-w-7xl items-center px-6 sm:px-8 lg:px-10">
          <div className="max-w-4xl -translate-y-6 text-white sm:-translate-y-8">
            {/* Eyebrow */}
            <p className="mb-3 text-xs font-semibold uppercase tracking-[0.22em] text-[#02BAF1]">
              {slide.eyebrow}
            </p>

            {/* Heading */}
            <h1 className="text-4xl font-extrabold leading-[1.05] tracking-tight sm:text-5xl lg:text-6xl">
              {slide.title}
              <br />
              <span className="text-[#02BAF1]">
                {slide.highlight}
              </span>
            </h1>

            {/* Description */}
            <p className="mt-4 max-w-2xl text-sm leading-6 text-slate-200 sm:text-base">
              {slide.description}
            </p>

            {/* Buttons */}
            <div className="mt-6 flex flex-wrap gap-3">
              <button
                type="button"
                className="
                  rounded-lg
                  bg-[#02BAF1]
                  px-6
                  py-3
                  text-sm
                  font-semibold
                  text-[#06203B]
                  transition
                  duration-300
                  hover:bg-white
                "
              >
                Explore College
              </button>

              <button
                type="button"
                className="
                  rounded-lg
                  border
                  border-white/30
                  bg-white/10
                  px-6
                  py-3
                  text-sm
                  font-semibold
                  text-white
                  backdrop-blur-sm
                  transition
                  duration-300
                  hover:bg-white
                  hover:text-[#0F3262]
                "
              >
                View Admissions
              </button>
            </div>
          </div>
        </div>

        {/* College Statistics */}
        <div className="absolute bottom-0 left-0 right-0 z-30 px-4 pb-5 sm:px-6">
          <div className="mx-auto grid max-w-5xl grid-cols-2 gap-3 lg:grid-cols-4 lg:gap-4">
            {statistics.map((stat) => (
              <div
                key={stat.label}
                className="
                  flex
                  min-h-23
                  flex-col
                  items-center
                  justify-center
                  rounded-2xl
                  border
                  border-slate-200
                  bg-white
                  px-4
                  py-3
                  text-center
                  shadow-[0_8px_25px_rgba(15,23,42,0.14)]
                  transition
                  duration-300
                  hover:-translate-y-1
                "
              >
                <div className="text-2xl font-bold tracking-tight text-[#0F3262] sm:text-3xl">
                  {stat.value}
                </div>

                <div className="mt-1 text-xs font-medium text-[#0F3262] sm:text-sm">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Slider Dots */}
        <div className="absolute bottom-2 left-1/2 z-40 flex -translate-x-1/2 gap-2">
          {slides.map((_, index) => (
            <button
              key={index}
              type="button"
              onClick={() => setCurrent(index)}
              aria-label={`Go to slide ${index + 1}`}
              className={`
                h-1.5
                rounded-full
                transition-all
                duration-300
                ${
                  index === current
                    ? "w-7 bg-[#02BAF1]"
                    : "w-1.5 bg-white/60 hover:bg-white"
                }
              `}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

export default HeroSlider;