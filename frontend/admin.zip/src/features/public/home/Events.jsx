// import React from "react";
import { CalendarDays, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const events = [
  {
    date: "15",
    month: "AUG",
    title: "Independence Day Celebration",
    category: "Campus Event",
  },
  {
    date: "22",
    month: "AUG",
    title: "Academic Seminar",
    category: "Academic",
  },
  {
    date: "05",
    month: "SEP",
    title: "Teachers' Day Programme",
    category: "Activities",
  },
];

const Events = () => {
  return (
    <section className="py-12 lg:py-10 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-5 mb-10">

          <div>
            <span className="text-sm font-semibold text-blue-700 uppercase tracking-wide">
              Campus Life
            </span>

            <h2 className="mt-2 text-3xl sm:text-4xl font-bold text-slate-900">
              Activities & Events
            </h2>

            <p className="mt-3 text-slate-500 max-w-2xl">
              Stay connected with academic activities, campus programmes,
              seminars and important institutional events.
            </p>
          </div>

          <Link
            to="/events"
            className="inline-flex items-center gap-2 text-sm font-semibold text-blue-700 hover:text-blue-800"
          >
            View All Events
            <ArrowRight size={17} />
          </Link>

        </div>

        {/* Events */}
        <div className="grid md:grid-cols-3 gap-6">

          {events.map((event, index) => (
            <article
              key={index}
              className="
                group
                rounded-2xl
                border border-slate-200
                bg-white
                overflow-hidden
                hover:shadow-xl
                hover:-translate-y-1
                transition-all duration-300
              "
            >

              {/* Event Image */}
              <div className="aspect-vedio bg-slate-100 overflow-hidden">

                <img
                  src={
                    [
                      "https://images.unsplash.com/photo-1523580846011-d3a5bc25702b",
                      "https://images.unsplash.com/photo-1540575467063-178a50c2df87",
                      "https://images.unsplash.com/photo-1524178232363-1fb2b075b655",
                    ][index]
                  }
                  alt={event.title}
                  className="
                    w-full h-full object-cover
                    group-hover:scale-105
                    transition duration-500
                  "
                />

              </div>

              {/* Event Details */}
              <div className="p-5">

                <div className="flex gap-4">

                  {/* Date */}
                  <div className="
                    shrink-0
                    w-14 h-14
                    rounded-xl
                    bg-blue-50
                    text-blue-700
                    flex flex-col
                    items-center justify-center
                  ">
                    <span className="text-xl font-bold leading-none">
                      {event.date}
                    </span>

                    <span className="text-[10px] font-bold mt-1">
                      {event.month}
                    </span>
                  </div>

                  {/* Title */}
                  <div>
                    <span className="text-xs font-semibold text-blue-700">
                      {event.category}
                    </span>

                    <h3 className="mt-1 font-semibold text-slate-800 leading-6">
                      {event.title}
                    </h3>
                  </div>

                </div>

                <div className="
                  mt-5 pt-4
                  border-t border-slate-100
                  flex items-center gap-2
                  text-xs text-slate-500
                ">
                  <CalendarDays size={15} />
                  Upcoming Event
                </div>

              </div>

            </article>
          ))}

        </div>

      </div>
    </section>
  );
};

export default Events;